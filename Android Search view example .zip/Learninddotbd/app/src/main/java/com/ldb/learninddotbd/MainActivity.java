package com.ldb.learninddotbd;


import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listv_iew;

    // Define array adapter for ListView
    ArrayAdapter<String> adapter;

    // Define array List for List View data
    ArrayList<String> data_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initialise ListView with id
        listv_iew = findViewById(R.id.listv_iew);

        // Add items to Array List
        data_list = new ArrayList<>();
        data_list.add("Australia");
        data_list.add("Banglades");
        data_list.add("Canada");
        data_list.add("Dubai");
        data_list.add("England");
        data_list.add("Finland");
        data_list.add("Germany");
        data_list.add("Apple");
        data_list.add("Banana");
        data_list.add("Pineapple");
        data_list.add("Orange");
        data_list.add("Lychee");
        data_list.add("Guava");
        data_list.add("Peech");
        data_list.add("Melon");
        data_list.add("Watermelon");
        data_list.add("Papaya");
        data_list.add("C");
        data_list.add("C++");
        data_list.add("C#");
        data_list.add("Java");
        data_list.add("Advanced java");
        data_list.add("Interview prep with c++");
        data_list.add("Interview prep with java");
        data_list.add("data structures with c");
        data_list.add("data structures with java");

        // Set adapter to ListView-
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, data_list);
        listv_iew.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate menu with items using MenuInflator-
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);

        // Initialise menu item search bar-
        // with id and take its object-
        MenuItem searchViewItem = menu.findItem(R.id.search_bar);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchViewItem);

        // attach setOnQueryTextListener-
        // to search view defined above-
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            // Override onQueryTextSubmit method which is call when submit query is searched-
            @Override
            public boolean onQueryTextSubmit(String query) {
                // If the list contains the search query than filter the adapter-
                // using the filter method with the query as its argument-
                if (data_list.contains(query)) {
                    adapter.getFilter().filter(query);
                } else {
                    // Search query not found in List View-
                    Toast.makeText(MainActivity.this, "Item Not found", Toast.LENGTH_LONG).show();
                }
                return false;
            }

            // This method is overridden to filter the adapter according-
            // to a search query when the user is typing search-
            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }
}
// Thanks for visiting Learning dot bd